package KHAI_BAO_LOP_DOI_TUONG.KhaoBaoLopHinhChuNhat;

import java.util.*;

public class Main {
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        Rectange x = new Rectange(sc.nextDouble(), sc.nextDouble(), sc.next());
        System.out.println(x.toString());
    }

}
