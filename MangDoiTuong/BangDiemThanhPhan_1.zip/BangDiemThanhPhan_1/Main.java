package MangDoiTuong.BangDiemThanhPhan_1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class Main {
    public static void main(String []args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        ArrayList<SinhVien> ds = new ArrayList<>();
        while (t-- > 0) {
            sc.nextLine();
            ds.add(new SinhVien(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextDouble(), sc.nextDouble(), sc.nextDouble()));
        }
        Collections.sort(ds);
        int i = 1;
        for (SinhVien tmp : ds) {
            System.out.println(tmp);
        }
    }
}
