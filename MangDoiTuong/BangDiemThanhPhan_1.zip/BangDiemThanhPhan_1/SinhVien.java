package MangDoiTuong.BangDiemThanhPhan_1;

public class SinhVien implements Comparable<SinhVien> {
    private static int dem = 1;
    private String stt, id, name, clas;
    private double score1, score2, score3;

    public SinhVien() {
        this("", "name", "", 0.0, 0.0, 0.0);
    }

    public SinhVien(String id, String name, String clas, double score1, double score2, double score3) {
        this.stt = String.format("%d", dem++);
        this.id = id;
        this.name = name;
        this.clas = clas;
        this.score1 = score1;
        this.score2 = score2;
        this.score3 = score3;
    }

    @Override
    public int compareTo(SinhVien o) {
        return this.id.compareTo(o.id);
    }

    @Override
    public String toString() {
        return String.format("%s %s %s %s %.1f %.1f %.1f", stt, id, name, clas, score1, score2, score3);
    }
}