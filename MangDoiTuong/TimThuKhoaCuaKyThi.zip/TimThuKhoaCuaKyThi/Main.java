package MangDoiTuong.TimThuKhoaCuaKyThi;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        sc.nextLine();
        ArrayList<ThiSinh> ds = new ArrayList<>();
        double max = 0;

        while(t-- > 0) {
            ThiSinh ts = new ThiSinh(sc.nextLine(),sc.nextLine(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
            ds.add(ts);
            double tmp = ts.getTotalScore();
            if (tmp > max) max = tmp;
        }
        for (ThiSinh diem : ds){
            if(diem.getTotalScore() == max) System.out.println(diem);
        }
    }
}
