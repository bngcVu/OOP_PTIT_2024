package MangDoiTuong.TimThuKhoaCuaKyThi;

public class ThiSinh {
    private static int dem = 1;
    private int stt;
    private String name,birthDay;
    private double score1,score2,score3,totalScore;

    ThiSinh(String name, String birthDay, double score1, double score2, double score3) {
        this.stt = dem++;
        this.name = name;
        this.birthDay = birthDay;
        this.score1 = score1;
        this.score2 = score2;
        this.score3 = score3;
        this.totalScore = score1+score2+score3;
    }
    double getTotalScore(){
        return this.totalScore;
    }

    @Override
    public String toString(){
        return String.valueOf(this.stt)+' '+this.name+' '+this.birthDay+' '+this.totalScore;
    }
}
